package com.example.touchreleasetest;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setContentView(new TouchView());
    }

    class TouchView extends View {
        Paint p = new Paint(3);
        float x = -1, y = -1;
        String status = "화면을 누른 채 좌우로 움직여 보세요";
        TouchView() { super(MainActivity.this); setBackgroundColor(Color.rgb(25,28,35)); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            x = e.getX(); y = e.getY();
            if (e.getAction() == MotionEvent.ACTION_DOWN) status = "누르는 중…";
            else if (e.getAction() == MotionEvent.ACTION_MOVE) status = "이동 중…";
            else if (e.getAction() == MotionEvent.ACTION_UP) {
                status = (x < getWidth()/2f ? "손을 뗀 위치: A 영역" : "손을 뗀 위치: B 영역")
                    + String.format("  (X %.0f / 화면폭 %.0f)", x, (float)getWidth());
            }
            invalidate();
            return true;
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float mid = getWidth()/2f;
            p.setColor(Color.rgb(46,105,180)); c.drawRect(0,0,mid,getHeight(),p);
            p.setColor(Color.rgb(31,135,100)); c.drawRect(mid,0,getWidth(),getHeight(),p);
            p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(54);
            c.drawText("A 영역", mid/2, getHeight()/2f, p);
            c.drawText("B 영역", mid+(getWidth()-mid)/2, getHeight()/2f, p);
            p.setTextSize(25);
            c.drawText(status, getWidth()/2f, 65, p);
            if (x >= 0) {
                p.setColor(Color.YELLOW); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5);
                c.drawCircle(x,y,22,p); p.setStyle(Paint.Style.FILL);
            }
            p.setColor(Color.WHITE); p.setTextSize(22);
            c.drawText("이 앱 안에서만 터치 좌표를 확인하는 테스트입니다.", getWidth()/2f, getHeight()-35, p);
        }
    }
}
